const DEFAULT_SETTINGS = Object.freeze({
  enabled: true,
  rememberWindowBounds: true
});

const STARTUP_RESTORE_STATE_KEY = "startupRestoreState";
const STARTUP_SETTLE_DELAY_MS = 800;
const SESSION_RETRY_DELAYS_MS = Object.freeze([0, 1000, 2000, 4000, 6000]);
const WINDOW_APPLY_DELAY_MS = 300;
const CAPTURE_AFTER_FOCUS_MS = 400;

let startupRestoreTask = null;
let startupRestoreInProgress = false;
let firstNormalWindowId;
let focusCaptureTimer;

chrome.runtime.onInstalled.addListener(() => {
  void initializeSettingsAndCaptureWindow();
});

chrome.runtime.onStartup.addListener(() => {
  // 프로필이 백그라운드에서 먼저 시작되더라도 첫 일반 창까지 대기합니다.
  startupRestoreInProgress = true;
  void armStartupRestore();
});

chrome.windows.onCreated.addListener((window) => {
  if (!isUsableNormalWindow(window)) {
    return;
  }

  if (!Number.isInteger(firstNormalWindowId)) {
    firstNormalWindowId = window.id;
  }

  startupRestoreInProgress = true;
  void queuePendingStartupRestore(firstNormalWindowId);
});

chrome.windows.onBoundsChanged.addListener((window) => {
  void saveWindowBoundsIfEnabled(window);
});

chrome.windows.onFocusChanged.addListener((windowId) => {
  if (
    windowId === chrome.windows.WINDOW_ID_NONE ||
    startupRestoreInProgress
  ) {
    return;
  }

  clearTimeout(focusCaptureTimer);
  focusCaptureTimer = setTimeout(() => {
    void captureWindowById(windowId);
  }, CAPTURE_AFTER_FOCUS_MS);
});

chrome.storage.onChanged.addListener((changes, areaName) => {
  if (
    areaName === "local" &&
    changes.rememberWindowBounds?.newValue === true
  ) {
    void captureLastFocusedWindow();
  }
});

async function initializeSettingsAndCaptureWindow() {
  try {
    const stored = await chrome.storage.local.get([
      "enabled",
      "rememberWindowBounds"
    ]);
    const updates = {};

    if (typeof stored.enabled !== "boolean") {
      updates.enabled = DEFAULT_SETTINGS.enabled;
    }

    if (typeof stored.rememberWindowBounds !== "boolean") {
      updates.rememberWindowBounds = DEFAULT_SETTINGS.rememberWindowBounds;
    }

    if (Object.keys(updates).length > 0) {
      await chrome.storage.local.set(updates);
    }

    if (
      stored.rememberWindowBounds === true ||
      updates.rememberWindowBounds === true
    ) {
      await captureLastFocusedWindow();
    }
  } catch (error) {
    console.error("초기 설정 또는 창 위치를 저장하지 못했습니다.", error);
  }
}

async function armStartupRestore() {
  try {
    await chrome.storage.session.set({
      [STARTUP_RESTORE_STATE_KEY]: "pending"
    });

    const initialWindowId =
      firstNormalWindowId ?? (await getLastFocusedNormalWindowId());

    if (!Number.isInteger(initialWindowId)) {
      // onCreated가 나중에 서비스 워커를 다시 깨워 복원을 이어갑니다.
      startupRestoreInProgress = false;
      console.info("첫 일반 브라우저 창이 열릴 때까지 복원을 대기합니다.");
      return;
    }

    firstNormalWindowId = initialWindowId;

    // onCreated가 pending 저장보다 먼저 실행된 경우 그 작업을 마친 뒤 재확인합니다.
    if (startupRestoreTask) {
      await startupRestoreTask;
    }

    const currentState = await chrome.storage.session.get(
      STARTUP_RESTORE_STATE_KEY
    );

    if (currentState[STARTUP_RESTORE_STATE_KEY] !== "pending") {
      return;
    }

    await queuePendingStartupRestore(initialWindowId);
  } catch (error) {
    startupRestoreInProgress = false;
    console.error("시작 복원 대기 상태를 만들지 못했습니다.", error);
  }
}

function queuePendingStartupRestore(candidateWindowId) {
  if (startupRestoreTask) {
    return startupRestoreTask;
  }

  startupRestoreInProgress = true;
  startupRestoreTask = runPendingStartupRestore(candidateWindowId).finally(() => {
    startupRestoreTask = null;
  });

  return startupRestoreTask;
}

async function runPendingStartupRestore(candidateWindowId) {
  let claimedPendingRestore = false;

  try {
    const startupState = await chrome.storage.session.get(
      STARTUP_RESTORE_STATE_KEY
    );

    if (startupState[STARTUP_RESTORE_STATE_KEY] !== "pending") {
      startupRestoreInProgress = false;
      return;
    }

    const initialWindowId = await resolveUsableInitialWindowId(
      candidateWindowId
    );

    if (!Number.isInteger(initialWindowId)) {
      startupRestoreInProgress = false;
      return;
    }

    const initialWindowSnapshot = await captureInitialWindowSnapshot(
      initialWindowId
    );

    await chrome.storage.session.set({
      [STARTUP_RESTORE_STATE_KEY]: "running"
    });
    claimedPendingRestore = true;

    await wait(STARTUP_SETTLE_DELAY_MS);
    await restoreAtStartup(initialWindowId, initialWindowSnapshot);
  } catch (error) {
    console.error("시작 시 자동 복원에 실패했습니다.", error);
  } finally {
    if (claimedPendingRestore) {
      try {
        await chrome.storage.session.set({
          [STARTUP_RESTORE_STATE_KEY]: "done"
        });
      } catch (error) {
        console.error("시작 복원 완료 상태를 저장하지 못했습니다.", error);
      }
    }

    if (claimedPendingRestore) {
      // windows.update()와 초기 창 종료로 발생한 이벤트가 값을 덮어쓰지 않게 합니다.
      setTimeout(() => {
        startupRestoreInProgress = false;
      }, WINDOW_APPLY_DELAY_MS);
    } else {
      startupRestoreInProgress = false;
    }
  }
}

async function restoreAtStartup(initialWindowId, initialWindowSnapshot) {
  const settings = await chrome.storage.local.get({
    ...DEFAULT_SETTINGS,
    lastWindowBounds: null
  });

  let restoreResult = {
    windowId: undefined,
    restoredAsWindow: false
  };

  if (settings.enabled === true) {
    restoreResult = await restoreMostRecentSessionWithRetry();
  } else {
    console.info("최근 세션 자동 복원이 꺼져 있습니다.");
  }

  const targetWindowId = restoreResult.windowId ?? initialWindowId;

  if (settings.rememberWindowBounds === true) {
    if (Number.isInteger(targetWindowId)) {
      await wait(WINDOW_APPLY_DELAY_MS);
      await applySavedWindowBounds(targetWindowId, settings.lastWindowBounds);
    }
  } else {
    console.info("창 위치 및 크기 복원이 꺼져 있습니다.");
  }

  await closeInitialWindowAfterRestore(
    initialWindowId,
    initialWindowSnapshot,
    restoreResult
  );
}

async function restoreMostRecentSessionWithRetry() {
  for (
    let attempt = 0;
    attempt < SESSION_RETRY_DELAYS_MS.length;
    attempt += 1
  ) {
    const retryDelay = SESSION_RETRY_DELAYS_MS[attempt];

    if (retryDelay > 0) {
      await wait(retryDelay);
    }

    try {
      const recentlyClosed = await chrome.sessions.getRecentlyClosed({
        maxResults: 1
      });
      const mostRecentSession = recentlyClosed[0];
      const sessionId =
        mostRecentSession?.tab?.sessionId ??
        mostRecentSession?.window?.sessionId;

      if (!sessionId) {
        if (attempt < SESSION_RETRY_DELAYS_MS.length - 1) {
          console.info(
            `최근 세션이 아직 준비되지 않아 재시도합니다. (${attempt + 1}/${SESSION_RETRY_DELAYS_MS.length - 1})`
          );
          continue;
        }

        console.info("여러 번 확인했지만 복원할 최근 탭 또는 창이 없습니다.");
        return { windowId: undefined, restoredAsWindow: false };
      }

      const restoredSession = await chrome.sessions.restore(sessionId);
      const restoredAsWindow = Boolean(restoredSession?.window);
      const windowId =
        restoredSession?.window?.id ?? restoredSession?.tab?.windowId;

      console.info("가장 최근에 닫힌 탭 또는 창을 복원했습니다.");
      return {
        windowId: Number.isInteger(windowId) ? windowId : undefined,
        restoredAsWindow
      };
    } catch (error) {
      if (attempt < SESSION_RETRY_DELAYS_MS.length - 1) {
        console.warn("최근 세션 조회 또는 복원에 실패해 재시도합니다.", error);
        continue;
      }

      console.error("최근 세션 복원에 최종 실패했습니다.", error);
    }
  }

  return { windowId: undefined, restoredAsWindow: false };
}

async function closeInitialWindowAfterRestore(
  initialWindowId,
  initialWindowSnapshot,
  restoreResult
) {
  if (
    restoreResult.restoredAsWindow !== true ||
    !Number.isInteger(initialWindowId) ||
    !Number.isInteger(restoreResult.windowId) ||
    initialWindowId === restoreResult.windowId
  ) {
    return;
  }

  try {
    const [initialWindow, restoredWindow] = await Promise.all([
      chrome.windows.get(initialWindowId, { populate: true }),
      chrome.windows.get(restoreResult.windowId)
    ]);

    if (
      !isUsableNormalWindow(initialWindow) ||
      !isUsableNormalWindow(restoredWindow)
    ) {
      return;
    }

    if (!doesWindowMatchSnapshot(initialWindow, initialWindowSnapshot)) {
      console.info(
        "시작 창의 탭이 변경되어 사용자 작업 보호를 위해 창을 유지합니다."
      );
      return;
    }

    await chrome.windows.remove(initialWindowId);
    console.info("복원 창이 열려 시작 시 생성된 초기 창을 닫았습니다.");
  } catch (error) {
    console.warn("시작 시 생성된 초기 창을 닫지 못했습니다.", error);
  }
}

async function captureInitialWindowSnapshot(windowId) {
  try {
    const window = await chrome.windows.get(windowId, { populate: true });

    if (!isUsableNormalWindow(window)) {
      return null;
    }

    const tabIds = (window.tabs ?? [])
      .map((tab) => tab.id)
      .filter(Number.isInteger);

    if (tabIds.length === 0) {
      return null;
    }

    return { windowId, tabIds };
  } catch (error) {
    console.info("시작 창 상태를 기록하지 못해 자동으로 닫지 않습니다.", error);
    return null;
  }
}

function doesWindowMatchSnapshot(window, snapshot) {
  if (
    !snapshot ||
    snapshot.windowId !== window.id ||
    !Array.isArray(snapshot.tabIds)
  ) {
    return false;
  }

  const currentTabIds = (window.tabs ?? [])
    .map((tab) => tab.id)
    .filter(Number.isInteger);

  return (
    currentTabIds.length === snapshot.tabIds.length &&
    currentTabIds.every((tabId, index) => tabId === snapshot.tabIds[index])
  );
}

async function applySavedWindowBounds(windowId, savedBounds) {
  if (!isValidSavedBounds(savedBounds)) {
    console.info("저장된 창 위치 및 크기가 아직 없습니다.");
    return;
  }

  try {
    // 최대화 상태와 좌표/크기는 한 번의 update 호출에서 함께 쓸 수 없습니다.
    await chrome.windows.update(windowId, { state: "normal" });
    await chrome.windows.update(windowId, {
      left: savedBounds.left,
      top: savedBounds.top,
      width: savedBounds.width,
      height: savedBounds.height
    });

    if (savedBounds.state === "maximized") {
      await chrome.windows.update(windowId, { state: "maximized" });
    }

    console.info("마지막 창 위치와 크기를 복원했습니다.");
  } catch (error) {
    console.error("창 위치와 크기를 복원하지 못했습니다.", error);
  }
}

async function captureLastFocusedWindow() {
  if (startupRestoreInProgress) {
    return;
  }

  try {
    const window = await chrome.windows.getLastFocused({
      windowTypes: ["normal"]
    });
    await saveWindowBoundsIfEnabled(window);
  } catch (error) {
    console.warn("마지막으로 사용한 창을 확인하지 못했습니다.", error);
  }
}

async function captureWindowById(windowId) {
  if (startupRestoreInProgress) {
    return;
  }

  try {
    const window = await chrome.windows.get(windowId);
    await saveWindowBoundsIfEnabled(window);
  } catch (error) {
    console.warn("선택한 창의 위치를 확인하지 못했습니다.", error);
  }
}

async function saveWindowBoundsIfEnabled(window) {
  if (startupRestoreInProgress) {
    return;
  }

  const savedBounds = createSavedBounds(window);

  if (!savedBounds) {
    return;
  }

  try {
    const { rememberWindowBounds = DEFAULT_SETTINGS.rememberWindowBounds } =
      await chrome.storage.local.get("rememberWindowBounds");

    if (rememberWindowBounds !== true) {
      return;
    }

    await chrome.storage.local.set({ lastWindowBounds: savedBounds });
    console.info("현재 창 위치와 크기를 저장했습니다.", savedBounds);
  } catch (error) {
    console.error("창 위치와 크기를 저장하지 못했습니다.", error);
  }
}

function createSavedBounds(window) {
  if (
    !isUsableNormalWindow(window) ||
    !["normal", "maximized"].includes(window.state)
  ) {
    return null;
  }

  const savedBounds = {
    left: window.left,
    top: window.top,
    width: window.width,
    height: window.height,
    state: window.state
  };

  return isValidSavedBounds(savedBounds) ? savedBounds : null;
}

function isValidSavedBounds(bounds) {
  return Boolean(
    bounds &&
      Number.isFinite(bounds.left) &&
      Number.isFinite(bounds.top) &&
      Number.isFinite(bounds.width) &&
      Number.isFinite(bounds.height) &&
      bounds.width >= 320 &&
      bounds.height >= 240 &&
      ["normal", "maximized"].includes(bounds.state)
  );
}

function isUsableNormalWindow(window) {
  return Boolean(
    window &&
      window.type === "normal" &&
      window.incognito !== true &&
      Number.isInteger(window.id)
  );
}

async function resolveUsableInitialWindowId(candidateWindowId) {
  if (Number.isInteger(candidateWindowId)) {
    try {
      const candidateWindow = await chrome.windows.get(candidateWindowId);

      if (isUsableNormalWindow(candidateWindow)) {
        return candidateWindowId;
      }
    } catch (error) {
      console.info("처음 감지한 창이 닫혀 다른 일반 창을 찾습니다.", error);
    }
  }

  return getLastFocusedNormalWindowId();
}

async function getLastFocusedNormalWindowId() {
  try {
    const window = await chrome.windows.getLastFocused({
      windowTypes: ["normal"]
    });
    return isUsableNormalWindow(window) ? window.id : undefined;
  } catch {
    return undefined;
  }
}

function wait(milliseconds) {
  return new Promise((resolve) => setTimeout(resolve, milliseconds));
}
