# Edge Auto Restore

Microsoft Edge가 새로 시작될 때 `Ctrl+Shift+T`와 비슷하게 가장 최근에 닫힌 탭 또는 창을 한 번 복원하고, 종료 전에 사용하던 창의 화면 위치와 크기를 다시 적용하는 Manifest V3 확장프로그램입니다.

최근 항목이 별도의 창으로 복원되면 Edge 시작 직후 먼저 만들어졌던 초기 창은 자동으로 닫습니다. 최근 항목이 탭이라서 초기 창 안에 복원되는 경우에는 해당 창을 유지합니다.

확장 아이콘을 누르면 **최근 탭·창 복원**과 **창 위치·크기 복원**을 각각 ON/OFF 할 수 있습니다. 설정과 마지막 창 좌표는 `chrome.storage.local`에 저장되므로 Edge나 컴퓨터를 다시 시작해도 유지됩니다. 두 기능 모두 최초 설치 시 기본값은 ON입니다.

## 설치

1. Microsoft Edge 주소 표시줄에 `edge://extensions`를 입력합니다.
2. 왼쪽 아래의 **개발자 모드**를 켭니다.
3. **압축해제된 확장 로드**를 누릅니다.
4. 이 `edge-auto-restore` 폴더를 선택합니다. `manifest.json` 파일이 바로 들어 있는 폴더여야 합니다.
5. 필요하면 도구 모음의 확장 메뉴에서 **Edge Auto Restore**를 고정합니다.

압축해제 방식으로 설치한 뒤에는 이 폴더를 이동하거나 삭제하지 마세요. 코드를 수정했다면 `edge://extensions`에서 확장 카드의 **새로 고침** 버튼을 눌러 반영할 수 있습니다.

## 사용 및 확인

1. `edge://extensions`에서 **Edge Auto Restore**의 **새로 고침**을 한 번 누릅니다. 기존 설치를 1.2.0 코드로 갱신할 때 필요합니다.
2. 확장 아이콘을 눌러 두 기능이 모두 ON인지 확인합니다.
3. 테스트용 탭 여러 개가 들어 있는 Edge 창을 원하는 위치로 옮기고 크기를 조절합니다. 최대화 상태도 저장할 수 있습니다.
4. 모든 Edge 창을 닫고 Edge 프로세스가 완전히 끝날 때까지 잠시 기다립니다.
5. Edge를 다시 실행합니다.
6. 브라우저가 관리하는 최근 닫은 항목 중 가장 최신 항목 한 개가 복원되고, 복원 대상 창에 저장된 좌표·크기·최대화 상태가 적용됩니다. 최근 항목이 별도 창으로 열리면 처음 실행된 빈 창은 닫힙니다.

두 기능은 독립적입니다. 예를 들어 최근 탭·창 복원은 끄고 창 위치·크기 복원만 켤 수 있습니다. ON/OFF 변경 자체는 현재 닫힌 항목이나 창 위치를 즉시 변경하지 않습니다. 창 위치 기능을 새로 켜면 현재 마지막으로 사용한 일반 Edge 창의 위치를 저장합니다.

## 동작 방식

- `chrome.runtime.onStartup`이 확장이 설치된 Edge 프로필의 시작을 감지합니다.
- 저장된 `enabled` 값이 `true`이면 최근 세션 복원을 실행합니다.
- `chrome.sessions.getRecentlyClosed({ maxResults: 1 })`로 가장 최근 항목 한 개를 조회합니다.
- 해당 항목의 `sessionId`를 `chrome.sessions.restore()`에 전달해 탭 또는 창을 복원합니다.
- 복원 결과가 새 창이고 시작 시 생성된 창과 ID가 다르면, 위치 적용이 끝난 뒤 `chrome.windows.remove()`로 초기 창만 닫습니다.
- `chrome.windows.onBoundsChanged`와 `onFocusChanged`로 마지막 일반 창의 좌표와 크기를 계속 갱신합니다.
- 저장된 `rememberWindowBounds` 값이 `true`이면 `chrome.windows.update()`로 복원된 창 또는 현재 시작 창에 마지막 위치를 적용합니다.
- 최대화 상태는 API 제약에 맞춰 일반 상태에서 좌표와 크기를 먼저 적용한 후 최대화합니다.
- 설치, 확장 새로 고침, 서비스 워커 재시작만으로는 복원하지 않습니다.

키 입력을 강제로 보내는 방식이 아니므로 실제 `Ctrl+Shift+T`를 누르는 것은 아닙니다. Chromium의 `sessions` API가 제공하는 최근 세션 목록을 이용해 같은 목적의 동작을 수행합니다.

## 중요한 제약

### Edge 프로세스가 살아 있으면 시작 이벤트가 다시 발생하지 않음

`runtime.onStartup`은 확장이 설치된 브라우저 프로필이 시작될 때 발생합니다. 모든 창을 닫았더라도 Edge 프로세스가 백그라운드에 계속 살아 있으면, 다음 창을 열 때 프로필이 새로 시작된 것이 아니므로 이벤트가 발생하지 않을 수 있습니다.

Edge의 **시작 부스트**는 로그인 시 Edge 프로세스를 미리 시작하거나 마지막 창이 닫힌 뒤 백그라운드에서 다시 시작할 수 있습니다. **Microsoft Edge가 닫혀 있을 때 백그라운드 확장 및 앱을 계속 실행** 옵션도 프로세스를 남길 수 있습니다. 완전 종료 후 재실행 동작이 꼭 필요하다면 다음 설정을 확인하세요.

1. `edge://settings/system`을 엽니다.
2. **시작 부스트**를 끕니다.
3. **Microsoft Edge가 닫혀 있을 때 백그라운드 확장 및 앱을 계속 실행**을 끕니다.
4. 작업 관리자에서 `msedge.exe`가 모두 종료됐는지 확인한 뒤 다시 테스트합니다.

조직에서 관리하는 PC에서는 정책 때문에 설정을 바꿀 수 없거나, 다른 Edge 기능 때문에 일부 프로세스가 남을 수 있습니다. 확장프로그램만으로 브라우저 프로세스의 완전 종료를 강제할 수는 없습니다.

### 최근 세션 데이터는 브라우저가 관리함

- 복원 대상과 보존 기간은 Edge가 관리하는 최근 세션 기록에 의존합니다. 기록이 없거나 Edge가 항목을 복원 가능 상태로 제공하지 않으면 아무것도 열리지 않습니다.
- 이 확장은 항목 한 개만 복원합니다. 최근 항목이 창이면 그 창 전체, 탭이면 그 탭 하나가 복원됩니다.
- 최근 항목이 탭이면 처음 생성된 창 안에 복원될 수 있으므로 초기 창을 닫지 않습니다. 별도 창 복원에 성공한 경우에만 서로 다른 ID의 초기 창을 닫습니다.
- InPrivate 프로필 시작에는 `runtime.onStartup`이 발생하지 않으며, 일반 프로필용 확장이 InPrivate 세션을 복원하도록 보장되지 않습니다.
- Edge 자체의 시작 설정이 **이전 세션의 탭 열기**로 되어 있으면 내장 복원과 이 확장의 복원이 겹치거나 예상과 다른 항목이 선택될 수 있습니다. 동작을 분리해 시험하려면 Edge 시작 설정을 새 탭 페이지로 두는 것이 좋습니다.
- 브라우저 충돌, 운영체제 종료 시점, 프로필 동기화 상태에 따라 최근 닫은 목록이 기대와 다를 수 있습니다.

### 창 위치 저장 및 복원의 범위

- 브라우저가 닫히는 바로 그 순간에 비동기 저장을 시작하면 완료를 보장할 수 없습니다. 이 확장은 종료 이벤트에 의존하지 않고 창 이동·크기 변경·포커스 변경 때마다 최신 위치를 미리 저장합니다.
- 여러 일반 Edge 창이 열려 있으면 마지막으로 이동, 크기 변경 또는 선택한 창의 위치 한 세트만 저장합니다. 모든 창의 배치를 각각 기억하는 기능은 아닙니다.
- 최소화 및 전체 화면 상태는 새 값으로 저장하지 않습니다. 마지막으로 확인된 일반 또는 최대화 상태를 유지합니다. 재실행 직후 창을 최소화된 상태로 숨기거나 F11 전체 화면으로 강제하지 않기 위한 동작입니다.
- 모니터를 분리하거나 해상도·배율·작업 표시줄 배치가 바뀌면 저장 좌표가 현재 화면 범위와 맞지 않을 수 있습니다. 이 경우 Edge 또는 Windows가 위치를 보정할 수 있으며, 창을 원하는 위치로 다시 옮기면 새 좌표가 저장됩니다.
- InPrivate 창과 팝업 창은 위치 저장 대상에서 제외합니다.

## 문제 확인

1. `edge://extensions`에서 **Edge Auto Restore** 카드를 찾습니다.
2. **서비스 워커** 링크를 눌러 개발자 도구를 엽니다.
3. Console에서 `현재 창 위치와 크기를 저장했습니다`, `마지막 창 위치와 크기를 복원했습니다`, `복원할 최근 탭 또는 창이 없습니다` 또는 오류 메시지를 확인합니다.
4. 권한이나 코드를 변경했다면 확장 카드의 **새로 고침**을 누른 뒤 다시 테스트합니다.

## 파일 구성

```text
edge-auto-restore/
├─ manifest.json
├─ background.js
├─ popup.html
├─ popup.js
├─ popup.css
└─ README.md
```

## 사용 권한과 개인정보

- `sessions`: 최근에 닫힌 탭 또는 창을 조회하고 복원하는 데 사용합니다.
- `storage`: ON/OFF 값과 마지막 일반 창의 좌표·크기·최대화 상태를 이 Edge 프로필에 저장하는 데 사용합니다.

외부 서버로 데이터를 전송하는 코드나 웹사이트 접근 권한은 포함되어 있지 않습니다.

창을 조회하고 배치하는 `chrome.windows` API 자체에는 별도의 Manifest 권한이 필요하지 않습니다. 이 확장은 탭 URL, 제목 또는 방문 기록을 읽지 않습니다.

## 참고 문서

- [Chrome Extensions `sessions` API](https://developer.chrome.com/docs/extensions/reference/api/sessions)
- [Chrome Extensions `runtime.onStartup`](https://developer.chrome.com/docs/extensions/reference/api/runtime#event-onStartup)
- [Chrome Extensions `windows` API](https://developer.chrome.com/docs/extensions/reference/api/windows)
- [Extension service worker lifecycle](https://developer.chrome.com/docs/extensions/develop/concepts/service-workers/lifecycle)
- [Microsoft Edge StartupBoostEnabled 정책 설명](https://learn.microsoft.com/en-us/deployedge/microsoft-edge-policies/startupboostenabled)
