const DEFAULT_SETTINGS = Object.freeze({
  enabled: true,
  rememberWindowBounds: true
});

const toggles = Array.from(document.querySelectorAll(".toggle"));
const statusText = document.querySelector("#statusText");

const settings = { ...DEFAULT_SETTINGS };

initializePopup();

async function initializePopup() {
  try {
    const stored = await chrome.storage.local.get(DEFAULT_SETTINGS);
    settings.enabled = stored.enabled === true;
    settings.rememberWindowBounds = stored.rememberWindowBounds === true;

    for (const toggle of toggles) {
      toggle.addEventListener("click", handleToggle);
      toggle.disabled = false;
    }

    renderSettings();
  } catch (error) {
    console.error("설정을 불러오지 못했습니다.", error);
    renderError("설정을 불러오지 못했습니다.");
  }
}

async function handleToggle(event) {
  const toggle = event.currentTarget;
  const settingName = toggle.dataset.setting;
  const nextValue = !settings[settingName];

  toggle.disabled = true;

  try {
    await chrome.storage.local.set({ [settingName]: nextValue });
    settings[settingName] = nextValue;
    renderSettings();
  } catch (error) {
    console.error("설정을 저장하지 못했습니다.", error);
    renderError("설정을 저장하지 못했습니다. 다시 시도해 주세요.");
  } finally {
    toggle.disabled = false;
  }
}

function renderSettings() {
  for (const toggle of toggles) {
    const settingName = toggle.dataset.setting;
    toggle.setAttribute("aria-checked", String(settings[settingName]));
  }

  const enabledCount = Object.values(settings).filter(Boolean).length;
  document.body.dataset.status = enabledCount === 0 ? "off" : "on";

  if (enabledCount === 2) {
    statusText.textContent = "세션과 창 위치를 다음 시작 때 복원합니다.";
  } else if (settings.enabled) {
    statusText.textContent = "최근 탭·창만 다음 시작 때 복원합니다.";
  } else if (settings.rememberWindowBounds) {
    statusText.textContent = "창 위치와 크기만 다음 시작 때 복원합니다.";
  } else {
    statusText.textContent = "모든 자동 복원 기능이 꺼져 있습니다.";
  }
}

function renderError(message) {
  document.body.dataset.status = "error";
  statusText.textContent = message;
}
