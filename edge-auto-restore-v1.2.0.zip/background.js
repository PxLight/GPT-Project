const DEFAULT_SETTINGS = Object.freeze({
  enabled: true,
  rememberWindowBounds: true
});

const STARTUP_RESTORE_DELAY_MS = 1200;
const WINDOW_APPLY_DELAY_MS = 300;
const CAPTURE_AFTER_FOCUS_MS = 400;

let startupRestoreScheduled = false;
let startupRestoreInProgress = false;
let focusCaptureTimer;

chrome.runtime.onInstalled.addListener(() => {
  void initializeSettingsAndCaptureWindow();
});

chrome.runtime.onStartup.addListener(() => {
  if (startupRestoreScheduled) {
    return;
  }

  startupRestoreScheduled = true;
  startupRestoreInProgress = true;

  // Edge가 시작 직후 최근 세션 목록과 첫 창을 준비할 시간을 잠시 줍니다.
  setTimeout(() => {
    void restoreAtStartup();
  }, STARTUP_RESTORE_DELAY_MS);
});

chrome.windows.onBoundsChanged.addListener((window) => {
  void saveWindowBoundsIfEnabled(window);
});

chrome.windows.onFocusChanged.addListener((windowId) => {
  if (
    windowId === chrome.windows.WINDOW_ID_NONE ||
    startupRestoreInProgress
  ) {
    return;
  }

  clearTimeout(focusCaptureTimer);
  focusCaptureTimer = setTimeout(() => {
    void captureWindowById(windowId);
  }, CAPTURE_AFTER_FOCUS_MS);
});

chrome.storage.onChanged.addListener((changes, areaName) => {
  if (
    areaName === "local" &&
    changes.rememberWindowBounds?.newValue === true
  ) {
    void captureLastFocusedWindow();
  }
});

async function initializeSettingsAndCaptureWindow() {
  try {
    const stored = await chrome.storage.local.get([
      "enabled",
      "rememberWindowBounds"
    ]);
    const updates = {};

    if (typeof stored.enabled !== "boolean") {
      updates.enabled = DEFAULT_SETTINGS.enabled;
    }

    if (typeof stored.rememberWindowBounds !== "boolean") {
      updates.rememberWindowBounds = DEFAULT_SETTINGS.rememberWindowBounds;
    }

    if (Object.keys(updates).length > 0) {
      await chrome.storage.local.set(updates);
    }

    if (
      stored.rememberWindowBounds === true ||
      updates.rememberWindowBounds === true
    ) {
      await captureLastFocusedWindow();
    }
  } catch (error) {
    console.error("초기 설정 또는 창 위치를 저장하지 못했습니다.", error);
  }
}

async function restoreAtStartup() {
  try {
    const settings = await chrome.storage.local.get({
      ...DEFAULT_SETTINGS,
      lastWindowBounds: null
    });

    const initialWindowId = await getLastFocusedNormalWindowId();
    let restoreResult = {
      windowId: undefined,
      restoredAsWindow: false
    };

    if (settings.enabled === true) {
      restoreResult = await restoreMostRecentSession();
    } else {
      console.info("최근 세션 자동 복원이 꺼져 있습니다.");
    }

    const targetWindowId = restoreResult.windowId ?? initialWindowId;

    if (settings.rememberWindowBounds === true) {
      if (Number.isInteger(targetWindowId)) {
        await wait(WINDOW_APPLY_DELAY_MS);
        await applySavedWindowBounds(targetWindowId, settings.lastWindowBounds);
      }
    } else {
      console.info("창 위치 및 크기 복원이 꺼져 있습니다.");
    }

    await closeInitialWindowAfterRestore(initialWindowId, restoreResult);
  } catch (error) {
    console.error("시작 시 자동 복원에 실패했습니다.", error);
  } finally {
    // windows.update()로 발생하는 bounds 이벤트가 저장값을 덮어쓰지 않게 합니다.
    setTimeout(() => {
      startupRestoreInProgress = false;
    }, WINDOW_APPLY_DELAY_MS);
  }
}

async function restoreMostRecentSession() {
  try {
    const recentlyClosed = await chrome.sessions.getRecentlyClosed({
      maxResults: 1
    });

    if (recentlyClosed.length === 0) {
      console.info("복원할 최근 탭 또는 창이 없습니다.");
      return { windowId: undefined, restoredAsWindow: false };
    }

    const mostRecentSession = recentlyClosed[0];
    const sessionId =
      mostRecentSession.tab?.sessionId ?? mostRecentSession.window?.sessionId;

    if (!sessionId) {
      console.warn("최근 세션에서 복원 가능한 sessionId를 찾지 못했습니다.");
      return { windowId: undefined, restoredAsWindow: false };
    }

    const restoredSession = await chrome.sessions.restore(sessionId);
    const restoredAsWindow = Boolean(restoredSession?.window);
    const windowId = restoredSession?.window?.id ?? restoredSession?.tab?.windowId;

    console.info("가장 최근에 닫힌 탭 또는 창을 복원했습니다.");
    return {
      windowId: Number.isInteger(windowId) ? windowId : undefined,
      restoredAsWindow
    };
  } catch (error) {
    console.error("최근 세션 복원에 실패했습니다.", error);
    return { windowId: undefined, restoredAsWindow: false };
  }
}

async function closeInitialWindowAfterRestore(initialWindowId, restoreResult) {
  if (
    restoreResult.restoredAsWindow !== true ||
    !Number.isInteger(initialWindowId) ||
    !Number.isInteger(restoreResult.windowId) ||
    initialWindowId === restoreResult.windowId
  ) {
    return;
  }

  try {
    const initialWindow = await chrome.windows.get(initialWindowId);

    if (initialWindow.type !== "normal" || initialWindow.incognito === true) {
      return;
    }

    await chrome.windows.remove(initialWindowId);
    console.info("복원 창이 열려 시작 시 생성된 초기 창을 닫았습니다.");
  } catch (error) {
    console.warn("시작 시 생성된 초기 창을 닫지 못했습니다.", error);
  }
}

async function applySavedWindowBounds(windowId, savedBounds) {
  if (!isValidSavedBounds(savedBounds)) {
    console.info("저장된 창 위치 및 크기가 아직 없습니다.");
    return;
  }

  try {
    // 최대화 상태와 좌표/크기는 한 번의 update 호출에서 함께 쓸 수 없습니다.
    await chrome.windows.update(windowId, { state: "normal" });
    await chrome.windows.update(windowId, {
      left: savedBounds.left,
      top: savedBounds.top,
      width: savedBounds.width,
      height: savedBounds.height
    });

    if (savedBounds.state === "maximized") {
      await chrome.windows.update(windowId, { state: "maximized" });
    }

    console.info("마지막 창 위치와 크기를 복원했습니다.");
  } catch (error) {
    console.error("창 위치와 크기를 복원하지 못했습니다.", error);
  }
}

async function captureLastFocusedWindow() {
  if (startupRestoreInProgress) {
    return;
  }

  try {
    const window = await chrome.windows.getLastFocused({
      windowTypes: ["normal"]
    });
    await saveWindowBoundsIfEnabled(window);
  } catch (error) {
    console.warn("마지막으로 사용한 창을 확인하지 못했습니다.", error);
  }
}

async function captureWindowById(windowId) {
  if (startupRestoreInProgress) {
    return;
  }

  try {
    const window = await chrome.windows.get(windowId);
    await saveWindowBoundsIfEnabled(window);
  } catch (error) {
    console.warn("선택한 창의 위치를 확인하지 못했습니다.", error);
  }
}

async function saveWindowBoundsIfEnabled(window) {
  if (startupRestoreInProgress) {
    return;
  }

  const savedBounds = createSavedBounds(window);

  if (!savedBounds) {
    return;
  }

  try {
    const { rememberWindowBounds = DEFAULT_SETTINGS.rememberWindowBounds } =
      await chrome.storage.local.get("rememberWindowBounds");

    if (rememberWindowBounds !== true) {
      return;
    }

    await chrome.storage.local.set({ lastWindowBounds: savedBounds });
    console.info("현재 창 위치와 크기를 저장했습니다.", savedBounds);
  } catch (error) {
    console.error("창 위치와 크기를 저장하지 못했습니다.", error);
  }
}

function createSavedBounds(window) {
  if (
    !window ||
    window.type !== "normal" ||
    window.incognito === true ||
    !["normal", "maximized"].includes(window.state)
  ) {
    return null;
  }

  const savedBounds = {
    left: window.left,
    top: window.top,
    width: window.width,
    height: window.height,
    state: window.state
  };

  return isValidSavedBounds(savedBounds) ? savedBounds : null;
}

function isValidSavedBounds(bounds) {
  return Boolean(
    bounds &&
      Number.isFinite(bounds.left) &&
      Number.isFinite(bounds.top) &&
      Number.isFinite(bounds.width) &&
      Number.isFinite(bounds.height) &&
      bounds.width >= 320 &&
      bounds.height >= 240 &&
      ["normal", "maximized"].includes(bounds.state)
  );
}

async function getLastFocusedNormalWindowId() {
  try {
    const window = await chrome.windows.getLastFocused({
      windowTypes: ["normal"]
    });
    return Number.isInteger(window.id) ? window.id : undefined;
  } catch (error) {
    console.warn("위치를 적용할 Edge 창을 찾지 못했습니다.", error);
    return undefined;
  }
}

function wait(milliseconds) {
  return new Promise((resolve) => setTimeout(resolve, milliseconds));
}
